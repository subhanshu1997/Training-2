package iocdemo1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		 ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
//		 Address add=context.getBean("add",Address.class);
		 Employee emp = context.getBean("emp", Employee.class);

			// Get Bean with ID emp, but DON'T assign Type
			Employee emp2 = (Employee) context.getBean("emp");

			System.out.println(emp.getFirstName());
			System.out.println(emp.getLastName());
			System.out.println(emp.getSalary());
			System.out.println(emp.getDesignation());
			System.out.println("First Phone: "+emp.getContacts().get(0));
			System.out.println("Second Phone: "+emp.getContacts().get(1));
			System.out.println(emp.getAddress().getCity());
	}

}
